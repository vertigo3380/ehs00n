x=int(input())
y=int(x/10)
y+=1
print(y*10)