x = 5
y=2/x
print(y)