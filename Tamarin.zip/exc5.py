x = 345
x = str(x)
x = x[::-1]
print(x)