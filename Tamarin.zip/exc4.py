age=input("write down your age")
age=int(age)
if age<=40:
    print("you are young")
else:
    print("you are old")