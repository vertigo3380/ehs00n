x = 20
y = 6
print(max(x , y))